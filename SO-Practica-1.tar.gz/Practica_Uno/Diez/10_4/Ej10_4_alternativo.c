//Archivo: Ej10_4_alternativo.c
#include <stdio.h>
#include <stdlib.h>
int main(){
	int * pi = (int *)malloc(sizeof(int));
	int * pj = (int *)malloc(sizeof(int));
	*pi = 11;
	pj = pi;
	printf("\n*pi=%d, *pj=%d\n", *pi, *pj);
	free(pj);
	// resto del c�digo ...
	return 0;
}
//Fin del archivo: Ej10_4_alternativo.c
