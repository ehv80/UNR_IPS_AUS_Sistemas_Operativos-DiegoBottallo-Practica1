//Archivo: Ej10_4.c
int main(){
	int *pi = malloc(sizeof(int));
	int *pj = malloc(sizeof(int));
	*pi = 11;
	pj = pi;
	printf("*pi=%d, *pj=%d", *pi, *pj);
	free(pj);
	// resto del c�digo ...
	return 0;
}
//Fin del archivo: Ej10_4.c
