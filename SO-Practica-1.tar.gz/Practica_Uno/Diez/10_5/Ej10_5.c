//Archivo: Ej10_5.c
#include <stdio.h>
int a, b;

void initialize() {
	if(a>0) b=1; else b=0;
}

int main() {
	a=1;
	initialize;
	printf("%d %d\n", a, b); /* sale 1 0 !!*/
	return 0;
}
//Fin del archivo: Ej10_5.c
