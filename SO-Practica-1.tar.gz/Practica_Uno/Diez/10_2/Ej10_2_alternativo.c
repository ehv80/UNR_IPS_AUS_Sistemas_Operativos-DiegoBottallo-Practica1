//Archivo: Ej10_2_alternativo.c
#include <stdio.h>
int main(){

	//int *ptr, a=34;
	int a=34, * ptra = &a;

	//int *ptr2=&b, b=45;
	int b=45, * ptrb = &b;

	*ptra = 39;
	*ptrb = 40;
	
	printf("\n%d =?= %d\n", a , *ptra );
	printf("\n%d =?= %d\n", b , *ptrb );

	return 0;
}
//Fin del Archivo: Ej10_2_alternativo.c
