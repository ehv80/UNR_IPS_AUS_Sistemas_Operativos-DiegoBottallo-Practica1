//Archivo: Ej10_2.c
int main(){
	int *ptr, a=34;
	int *ptr2=&b, b=45;
	*ptr = 34;
	printf("%d =?= %d" a, *ptr);

	return 0;
}
//Fin del Archivo: Ej10_2.c
