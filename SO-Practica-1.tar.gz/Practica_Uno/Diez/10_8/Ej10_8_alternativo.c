// Archivo: Ej10_8_alternativo.c
#include <stdio.h>
#define MAX(A,B) ((A)>(B)?(A):(B))

int main(){
	int i=8, j=4;
	printf("Que entero es mayor? %d o %d?", i, j);
	printf("\nEl mayor es %d\n", MAX(i,j) );
	return 0; // indica al entorno finalizaci�n exitosa
}
// Fin del archivo: Ej10_8_alternativo.c
