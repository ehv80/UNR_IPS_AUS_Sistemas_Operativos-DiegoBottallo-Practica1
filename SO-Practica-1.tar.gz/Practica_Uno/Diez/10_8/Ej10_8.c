// Archivo: Ej10_8.c
#define MAX(A,B) ((A)>(B)?(A):(B))

int main(){
	int i=8, j=4;

	printf("Que entero es mayor? %d o %d?", i, j);
	MAX(i++, j++);
	printf("\nEl mayor es %d", --i);
}
// Fin del archivo: Ej10_8.c
