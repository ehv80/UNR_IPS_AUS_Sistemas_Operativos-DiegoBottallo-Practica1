// Archivo: Ej10_i.c
#include <stdio.h>

typedef int NUMBER;
//typedef int COUNT;

/*** VARIABLES GLOBALES ***/
NUMBER a[] = {0,1,2,3,4,5,6,7,8,9};
NUMBER n = sizeof(a)/sizeof(a[0]);
NUMBER m,i,resultado;

/*** FUNCIONES ***/
NUMBER index( NUMBER a[] , NUMBER n , NUMBER m ) {
	NUMBER i;
	for(i=0 ; i<n ; i++ )
		if (m == a[i]) return m;
	return n;
}

/*** FUNCI�N PRINCIPAL: MAIN ***/
int main()
{
	printf("\n");
	for(i=0 ; i<n ; i++ )
		printf("\ta[%d] = %d\n" , i , a[i] );
	printf("INGRESE EL N�MERO QUE QUIERE BUSCAR EN EL ARREGLO: ");
	scanf("%d" , &m );
	resultado=index( a , n , m );
	printf("\nRESULTADO = %d\n" , resultado);
	printf("ACLARACI�N: SI resultado vale %d SIGNIFICA QUE EL ELEMENTO NO EST�!\n", n);

	return 0;
}	
// Fin del archivo: Ej10_i.c
