// Archivo: Ej10_i.c
typedef int NUMBER;
typedef int COUNT;

COUNT index (NUMBER a[] , COUNT n , NUMBER m) {
	COUNT i;
	for(i=0 ; i<n ; i++ )
		if (m == a[i]) return m;
	return n;
}
// Fin del archivo: Ej10_i.c
