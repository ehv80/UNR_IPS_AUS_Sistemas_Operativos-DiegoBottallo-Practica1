//Archivo: Ej10_3_alternativo.c

#include <string.h>
#include <stdlib.h>

int main(){
	int * p = malloc(20*sizeof(int));
	//memset( p, 20, 'a');
	memset( p, 'a' , 20 );
	free(p);
	return 0;
}
//Fin del archivo: Ej10_3_alternativo.c
