//Archivo: Ej10_3.c
#include <string.h>
int main(){
	int * p = malloc(20*sizeof(int))

	memset( p, 20, 'a');
	free(p);
	return 0;
}
//Fin del archivo: Ej10_3.c
