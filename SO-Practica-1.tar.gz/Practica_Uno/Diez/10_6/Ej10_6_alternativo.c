//Archivo: Ej10_6_alternativo.c

#include <stdio.h>

#define TRUE 1
#define FALSE 0
#define MAX 100

/*** VARIABLES GLOBALES ***/
int resultado;

/*** FUNCIONES ***/
int esPrimo(unsigned a) {	// precondic�n: a > 0
       int i, flag=TRUE;  	// retorna 1 si es primo, 0 en caso contrario
       for( i=2 ; i<a ; i++ )
               if(!(a % i)) flag=FALSE;
       return flag;
}
       
int main()
{
	int equis;
	for( equis=0 ; equis <= MAX ; equis++ )
	{
		resultado = esPrimo(equis);
		if( resultado==TRUE )
		{
			printf("\nEl n�mero %d es primo.\n" , equis );
		}
		else if( resultado==FALSE )
		{
			printf("\nEl n�mero %d no es primo.\n" , equis );
		}
	}

	return 0; //informa al entorno terminaci�n exitosa
}
//Fin del archivo: Ej10_6_alternativo.c
