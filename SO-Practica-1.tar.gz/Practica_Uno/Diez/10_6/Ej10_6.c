//Archivo: Ej10_6.c
int esPrimo(unsigned a) {	/* precondic�n: a > 0
	int i , flag = 1;	   retorna 1 si es primo, 0 en caso contrario */
	for( i = 2 ; i < a ; i++ )
		if(!(a % i)) flag = 0;
	
	return flag;
}
//Fin del archivo: Ej10_6.c
