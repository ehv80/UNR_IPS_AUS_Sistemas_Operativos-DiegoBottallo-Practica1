//Archivo: Ej10_7.c
struct vector {
	float x, y;
}

struct vector * normal(struct vector v) {
	struct vector *ptr;
	ptr->x = v.x;
	ptr->y = v.y;

	return ptr;
}
//Fin del archivo: Ej10_7.c
