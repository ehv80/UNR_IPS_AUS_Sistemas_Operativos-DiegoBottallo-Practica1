//Archivo: Ej10_7_alternativo.c
#include <stdlib.h>
#include <stdio.h>

typedef struct vector {
	float x, y;
} Vector;

typedef Vector * PtrVector;

PtrVector normal(Vector v) {
	PtrVector ptr = (PtrVector)(malloc(sizeof(v)));
	ptr->x = v.x;
	ptr->y = v.y;
	return ptr;
}

/*** FUNCI�N PRINCIPAL: main ***/
int main()
{
	Vector mivector;
	mivector.x=12.34;
	mivector.y=56.78;
	printf("\nmivector(x,y) = (%f,%f)\n", mivector.x, mivector.y);
	printf("\nAlocado en la direcci�n de Memoria: %p \n", &mivector);

	PtrVector punteroamivector = normal(mivector);
	printf("\npunteroamivector = (%f,%f)\n", punteroamivector->x, punteroamivector->y);
	printf("\nAlocado en la direcci�n de Memoria: %p \n", punteroamivector);
	
	return 0;	// Informa al entorno salida exitosa del programa.
}
//Fin del archivo: Ej10_7_alternativo.c
