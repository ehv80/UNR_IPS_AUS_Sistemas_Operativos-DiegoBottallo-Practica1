#include <stdio.h>
#include <stdlib.h> // para qsort

#define abs( x )  ( (x) >= 0 ? (x) : ( (x) * (-1) ) )

/*********************** VARIABLES GLOBALES ***************************/
unsigned int cuantos;
unsigned int modo;

/************************ PROTOTIPOS ****************************/
void inicializa( int arreglo[] );
void exibe( int arreglo[] );
void quicksort( int arreglo[] , int inicial , int final , int (* compara)( const void * , const void * ));
int compara( const void * arg1 , const void * arg2 );
void eligeModo( void );

/************************ FUNCIONES ****************************/

// inicializaci�n del arreglo interactiva.
void inicializa( int arreglo[] )
{
	int i; printf("\n INGRESE VALORES ENTEROS PARA EL ARREGLO: \n");
	for( i=0 ; i < cuantos ; i++ )
	{
		printf("\n	ARREGLO[%d] : " , i );
		scanf( "%d" , &( arreglo[i] ) );
	}
}

// Rutina de exibici�n del los elementos del arreglo en pantalla
void exibe( int arreglo[] )
{
	int i;
	printf("\n");
	for( i=0 ; i < cuantos ; i++ )
	{
		printf("   A[%d] = %d \n" , i , arreglo[i] );
	}
	printf("\n");
	
}

void eligeModo()
{
   printf("\nELIJA EL MODO DE ORDENACI�N DEL ARREGLO INTRODUCIENDO UNO DE ENTRE LOS SIGUIENTES VALORES:\n");
   printf("   1   REALIZA ORDENACI�N ASCENDENTE\n");
   printf("   2   REALIZA ORDENACI�N DESCENDENTE\n");
   printf("   3   REALIZA ORDENACI�N DE VALOR ABSOLUTO ASCENDENTE\n");
   printf("   4   REALIZA ORDENACI�N DE VALOR ABSOLUTO DESCENDENTE\n");
   scanf("%d" , &modo );
}
 
/* Funci�n que realiza la comparaci�n en la forma indicada por "modo"
 * una variable global que deber� ser valorizada por el usuario.
 */
int compara( const void * arg1 , const void * arg2  )
{
	int * pmodo = &modo;
	switch( *pmodo )
	{
		case 1:	// ascendente
			return ( *((int *)arg1) - *((int *)arg2) ); break;
		case 2:	// descendente
			return ( *((int *)arg2) - *((int *)arg1) ); break;
		case 3:	// valor absoluto ascendente
			{
				int tmp1 = *((int *)arg1); 
				int tmp2 = *((int *)arg2);
				tmp1 = abs(tmp1);
				tmp2 = abs(tmp2);
				return ( tmp1 - tmp2 );
			}
				break;
		case 4:	// valor absoluto descendente
			{
				int tmp1 , tmp2;
				tmp1 = *((int *) arg1);
				tmp2 = *((int *) arg2);
				tmp1 = abs(tmp1);
				tmp2 = abs(tmp2);
				return ( tmp2 - tmp1 );
			}
				break;
		default:	// mensaje aclaratorio
			{
			printf("EL MODO DE COMPARACI�N SE INDICA MEDIANTE UNO DE LOS SIGUIENTES VALORES:\n");
	   			printf("   1   REALIZA ORDENACI�N ASCENDENTE\n");
	   			printf("   2   REALIZA ORDENACI�N DESCENDENTE\n");
	   			printf("   3   REALIZA ORDENACI�N DE VALOR ABSOLUTO ASCENDENTE\n");
				printf("   4   REALIZA ORDENACI�N DE VALOR ABSOLUTO DESCENDENTE\n");
				printf("SE PROCEDER� A ORDENAR EN EL MODO DE ORDENACI�N POR DEFECTO: \n");
				printf("ORDENACI�N ASCENDENTE:");
				return ( *((int *)arg1) - *((int *)arg2) );
			}
			break;
	}
}

/* Funci�n: Ordena un arreglo de "n" n�meros enteros en orden creciente
 * de sus valores usando el algoritmo quicksort
 */ 
void quicksort( int arreglo[] , int inicial , int final ,
		int (*compara)( const void * arg1 , const void * arg2 )
	      )
{
	qsort( arreglo , cuantos , sizeof(int) , compara );
}


/************************ FUNCI�N PRINCIPAL MAIN ***************************/
int main()
{
	printf("INGRESE LA CANTIDAD DE ENTEROS QUE CONTENDR� EL ARREGLO: \n" );
	scanf( "%d" , &cuantos );
	int arreglo[cuantos];
	inicializa( arreglo );
	eligeModo();
	int inicial = 0, final = (cuantos - 1);
	quicksort( arreglo , inicial , final , compara );
	exibe( arreglo );
	return 0;	// informa al entorno finalizaci�n correcta
}
