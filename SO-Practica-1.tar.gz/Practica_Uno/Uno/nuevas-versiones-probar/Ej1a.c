#include <stdio.h>

#define TRUE 1
#define FALSE 0

/************************ VARIABLES GLOBALES ***************************/
unsigned int cuantos;

/************************ PROTOTIPOS ***************************/
void intercambia( int arreglo[] , int i , int j );
void inicializa( int arreglo[] );
void exibe( int arreglo[] );
int encuentraPivote( int arreglo[] , int inicial , int final );
int parteArreglo( int arreglo[] , int inicial , int final );
void quicksort( int arreglo[] , int inicial , int final );


/************************ FUNCIONES ***************************/
void intercambia( int arreglo[] , int i , int j )
{
	int tmp = arreglo[i];
	arreglo[i] = arreglo[j];
	arreglo[j] = tmp;
}

// inicializaci�n del arreglo interactiva.
void inicializa( int arreglo[] )
{
	int bandera = FALSE; 
	int aux; //variable de control para la cantidad ingresada por usuario
	do{
		printf("INGRESE LA CANTIDAD DE ENTEROS QUE CONTENDR� EL ARREGLO: \n" );
		scanf( "%d" , &aux );
		if( aux > 0 )
		{
			cuantos = (unsigned int)aux;
			bandera = TRUE;
			int i; 
			printf("\n INGRESE VALORES ENTEROS PARA EL ARREGLO: \n");
			for( i=0 ; i < cuantos ; i++ )
			{
				printf("\n	ARREGLO[%d] : " , i );
				scanf( "%d" , &( arreglo[i] ) );
			}
		}
		else
		{
			printf("\n La cantidad ingresada DEBE SER UN N�MERO ENTERO POSITIVO!!! \n");
		}
	}while( bandera == FALSE );
}

// Rutina de exibici�n de los elementos del arreglo en pantalla
void exibe( int arreglo[] )
{
	int i;
	printf("\n");
	for( i=0 ; i < cuantos ; i++ )
	{
		printf("   ARREGLO[%d] = %d \n" , i , arreglo[i] );
	}
	printf("\n");
	
}

/* Retorna 0 si es que todos los elementos del arreglo son id�nticos.
 * De lo contrario retorna el �ndice del mayor entre los primeros dos
 * elementos que se encuentran m�s a la izquierda en el arreglo.
 ***/
int encuentraPivote( int arreglo[] , int inicial , int final )
{
	int elementoUno = arreglo[inicial], k;
	for( k = inicial + 1; k <= final ; k++ )
	{
		if( arreglo[k] > elementoUno )
			return k;
		else if( arreglo[k] < elementoUno )
			return inicial;
	}
	return 0; // cuando todos los elementos del arreglo son id�nticos
}

/* Divide el arreglo de modo que los elementos MENORES que el
 * PIVOTE queden a la izquierda y los elementos MAYORES O IGUALES
 * que el PIVOTE queden a la derecha.
 * Retorna el �ndice donde quedar� el pivote.
 ***/
int parteArreglo( int arreglo[] , int inicial , int final )
{
	int indicePivote = encuentraPivote( arreglo , inicial , final );

	intercambia( arreglo , inicial , indicePivote );
	// ubica pivote al principio del arreglo
		
	int ultimoSubArregloIzquierdo = inicial, i;
	
	/* recorre el arreglo viendo: si el elemento es menor
	 * que pivote intercambia ese elemento con el que est� en
	 * el �ndice obtenido de sumar uno al �ndice 
	 * "ultimoSubArregloIzquierdo", que al principio es el inicial
	 * y al finalizar es efectivamente el �ndice siguiente al
	 * �ltimo elemento del subarreglo izquierdo que contiene
	 * a los elementos menores que pivote.
	 * Luego debe ubicarse el pivote a continuaci�n de
	 * estos elementos del subarreglo izquierdo
	 * es decir en el indice "ultimoSubArregloIzquierdo"
	 */
	for( i = inicial + 1 ; i <= final ; i++ )
	{
		if( arreglo[i] < arreglo[inicial] )
			intercambia( arreglo , ++ultimoSubArregloIzquierdo , i );
	}
		
	/* Aqu� reubica el pivote para que quede en el lugar 
	 * que le corresponde, su �ndice ser� "ultimoSubArregloIzquierdo"
	 */
	intercambia( arreglo , inicial , ultimoSubArregloIzquierdo );
	return ultimoSubArregloIzquierdo ; // �ndice donde finalmente queda el pivote
}

/* Funci�n: Ordena un arreglo de "n" n�meros enteros en orden creciente
 * de sus valores usando el algoritmo quicksort
 */ 
void quicksort( int arreglo[] , int inicial , int final )	
{
	if( inicial >= final ) 
		return;
	else
	{
		int indiceDelPivote = parteArreglo( arreglo , inicial, final );
		
		// aplica quicksort a subarreglo izquierdo de menores
		quicksort( arreglo , inicial, indiceDelPivote - 1 );

		// aplica quicksort a subarreglo derecho de mayores o iguales
		quicksort( arreglo , indiceDelPivote + 1 , final );
	}
}


/************************ FUNCI�N PRINCIPAL MAIN ***************************/
int main()
{
	int arreglo[cuantos];
	inicializa( arreglo );
	int inicial = 0, final = (cuantos - 1);
	quicksort( arreglo , inicial , final );
	exibe( arreglo );
	return 0;	// informa al entorno finalizaci�n correcta
}
