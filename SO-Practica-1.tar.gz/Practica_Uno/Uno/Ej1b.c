#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char * arr[]=
{
	"zapallo", "Hola", "Chau", "Muy", "bye", "Zapato", "Esta", "es", "una", "pequeña", "prueba"
};

static int cmp(const void * a, const void * b)
{
	const char ** pa = (const char **)a; 
	const char ** pb = (const char **)b; 
	return strcmp((*pa),(*pb));
}

int main ()
{
	int i;
	qsort(arr, sizeof(arr)/sizeof(arr[0]), sizeof(arr[0]),cmp);
	for(i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		printf("%s\n",arr[i]);
	return 0;
}
