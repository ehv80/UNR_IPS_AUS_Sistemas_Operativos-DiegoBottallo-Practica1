#include <stdio.h>
#include <stdlib.h>	// para "qsort" y "rand"

/******************* VARIABLES GLOBALES **********************/
unsigned int cuantos, buscado, resultado;


/************************ PROTOTIPOS *************************/
int compara( const void * , const void * );
int mibsearch( unsigned int * , unsigned int , unsigned int );
void inicializa( unsigned int * );
void exibe( unsigned int * );
void verificaYMuestra( unsigned int * , unsigned int );

/******************* FUNCIONES  **********************/

/* Funci�n de comparaci�n: solo en modo ascendente, pu�s el algoritmo
 * de b�squeda binaria requiere que los elementos del arreglo est�n ordenados.
 */
int compara( const void * arg1 , const void * arg2 )
{
	return ( *((unsigned int *)arg1) - *((unsigned int *)arg2) );
}

/* Funci�n que inicializa los valores del arreglo en forma aleatoria usando
 * la funci�n "rand"
 */
void inicializa( unsigned int * arreglo )
{
	int i; printf("\nINICIALIZANDO LOS ELEMENTOS DEL ARREGLO EN FORMA ALEATORIA���\n");
	for( i=0 ; i < cuantos ; i++ )
	{
		arreglo[i] = 1 + (int)( 10000.0 * rand()/(RAND_MAX + 1.0 ) );
		// se generan n�meros aleatorios entre 1 y 10000
		printf("��� ARREGLO[%d] = %d ��� \n" , i , arreglo[i] );
	}
	printf("\n");
}

// Rutina de exibici�n del los elementos del arreglo en pantalla
void exibe( unsigned int * arreglo )
{
         unsigned int i;
         printf("\n");
         for( i=0 ; i < cuantos ; i++ )
         {
		 printf("   ARREGLO[%u] = %u \n" , i , arreglo[i] );
	 }
	 printf("\n");
}

/* Funci�n que busca un elemento en un arreglo ordenado.
 * Retorna el �ndice en donde se encuentra en la primera aparici�n del elemento,
 * de lo contrario retorna -1
 */
int mibsearch( unsigned int * arreglo , unsigned int tamanio , unsigned int buscado )
{
	unsigned int min = 0 , max = (tamanio - 1) , central; //= ( min + ( max - min )/ 2 )
	if( buscado >= arreglo[min] && buscado <= arreglo[max] )
	{
		while( min <= max )
		{
			central = (unsigned int)( min + ( max - min )/2 );
			//para asegurarse que caiga en uno de los elementos del arreglo
			if( buscado == arreglo[central] )
				return central;	// lo encontr� y retorna su �ndice
			else if( buscado > arreglo[central] )
				min = central + 1;
			else
				max = central - 1;
			central = ( min + ( max - min )/2 );
		}
		// si no lo encuentra retorna -1 pues los elementos del arreglo son todos unsigned int
		// y de esta manera es f�cil distinguir que no se ha encontrado el elemento buscado
		return (-1);
	}
	else if( buscado < arreglo[min] || buscado > arreglo[max] )
	{
		printf("USTED INGRES� EL VALOR: %u \n" , buscado );
	printf("QUE ES MENOR QUE EL M�NIMO VALOR DEL ARREGLO, O MAYOR QUE EL M�XIMO VALOR DEL ARREGLO\n");
		printf("ES DECIR: NO SE ENCUENTRA EN EL ARREGLO! \n" );
		return -1;
	}
	return -1;
}

void verificaYmuestra( unsigned int * arreglo , unsigned int indiceResultado )
{
	if( indiceResultado == (-1) )
		printf("\nEL ENTERO SIN SIGNO BUSCADO NO SE ENCUENTRA EN EL ARREGLO\n" );
	else if( indiceResultado != (-1) )
	{
		printf("\nEL ENTERO SIN SIGNO: %u \n" , arreglo[indiceResultado] );
		printf("SE ENCUENTRA EN LA POSICI�N: %u \n" ,  indiceResultado );
	}
}		

/************************ FUNCI�N PRINCIPAL MAIN ***************************/
int main()
{
	printf("INGRESE LA CANTIDAD DE ENTEROS SIN SIGNO QUE CONTENDR� EL ARREGLO: \n" );
	scanf( "%u" , &cuantos );
	unsigned int arreglo[cuantos];
	inicializa( arreglo );
	qsort( arreglo , sizeof(arreglo)/sizeof(arreglo[0]) , sizeof(arreglo[0]) , compara );
	printf("EL ARREGLO ORDENADO EN FORMA ASCENDENTE: \n" );
	exibe( arreglo );
	printf("INGRESE EL VALOR DEL ENTERO SIN SIGNO QUE DESEA BUSCAR EN EL ARREGLO: \n" );
	scanf( "%u" , &buscado );
	resultado = mibsearch( arreglo , cuantos , buscado ); // posici�n en el arreglo � -1
	verificaYmuestra( arreglo , resultado ) ;
	return 0;       // informa al entorno finalizaci�n correcta
}
