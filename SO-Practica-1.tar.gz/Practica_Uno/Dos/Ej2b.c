#include <stdio.h>
#include <stdlib.h>	// para "qsort" y "bsearch" y "rand"

/******************* VARIABLES GLOBALES **********************/
unsigned int cuantos, buscado, * resultado;


/************************ PROTOTIPOS *************************/
int compara( const void * , const void * );
void inicializa( unsigned int * );
void exibe( unsigned int * );
void verificaYMuestra( unsigned int * , unsigned int * );

/******************* FUNCIONES  **********************/

/* Funci�n de comparaci�n:
 * 
 * Para "qsort": ordena solo en modo ascendente, pu�s el algoritmo
 * de b�squeda binaria requiere que los elementos del arreglo est�n ordenados.
 * 
 * Para "bsearch" se interpreta al primer argumento como un puntero al elemento que
 * se est� buscando, y al segundo argummento como un puntero a otro de los elementos del
 * arreglo. Entonces debe devolver un valor:
 * 	mayor que cero si elemento buscado es mayor que el otro elemento
 * 	menor que cero si    "        "    "  menor "   "   "    "
 * 	igual a cero   "     "        "    "  igual "   "   "    "	
 */
int compara( const void * arg1 , const void * arg2 )
{
	return ( *((unsigned int *)arg1) - *((unsigned int *)arg2) );
}

/* Funci�n que inicializa los valores del arreglo en forma aleatoria usando
 * la funci�n "rand"
 */
void inicializa( unsigned int * arreglo )
{
	int i; printf("\nINICIALIZANDO LOS ELEMENTOS DEL ARREGLO EN FORMA ALEATORIA���\n");
	for( i=0 ; i < cuantos ; i++ )
	{
		arreglo[i] = 1 + (int)( 10000.0 * rand()/(RAND_MAX + 1.0 ) );
		// se generan n�meros aleatorios entre 1 y 10000
		printf("��� ARREGLO[%d] = %d ��� \n" , i , arreglo[i] );
	}
	printf("\n");
}

// Rutina de exibici�n del los elementos del arreglo en pantalla
void exibe( unsigned int * arreglo )
{
         unsigned int i;
         printf("\n");
         for( i=0 ; i < cuantos ; i++ )
         {
		 printf("   ARREGLO[%u] = %u \n" , i , arreglo[i] );
	 }
	 printf("\n");
}

void verificaYmuestra( unsigned int * arreglo , unsigned int * resultado )
{
	if( resultado == NULL )
		printf("\nEL ENTERO SIN SIGNO BUSCADO NO SE ENCUENTRA EN EL ARREGLO\n" );
	else if( resultado != NULL )
	{
		printf("\nEL ENTERO SIN SIGNO: %u \n" , (*resultado) );
		//�No hay manera de saber en qu� posici�n est� en el arreglo?
		printf("SE ENCUENTRA EN LA DIRECCI�N DE MEMORIA: %p \n" , resultado );
		printf("ES DECIR EST� EN PRESENTE EN EL ARREGLO!!!\n"  );
	}
}		

/************************ FUNCI�N PRINCIPAL MAIN ***************************/
int main()
{
	printf("INGRESE LA CANTIDAD DE ENTEROS SIN SIGNO QUE CONTENDR� EL ARREGLO: \n" );
	scanf( "%u" , &cuantos );
	unsigned int arreglo[cuantos];
	inicializa( arreglo );
	qsort( arreglo , sizeof(arreglo)/sizeof(arreglo[0]) , sizeof(arreglo[0]) , compara );
	printf("EL ARREGLO ORDENADO EN FORMA ASCENDENTE: \n" );
	exibe( arreglo );
	printf("INGRESE EL VALOR DEL ENTERO SIN SIGNO QUE DESEA BUSCAR EN EL ARREGLO: \n" );
	scanf( "%u" , &buscado );
	resultado = (unsigned int *)bsearch( &buscado , arreglo , sizeof(arreglo)/sizeof(arreglo[0]) ,
			sizeof(arreglo[0]) , compara );
	verificaYmuestra( arreglo , resultado ) ;
	return 0;       // informa al entorno finalizaci�n correcta
}
