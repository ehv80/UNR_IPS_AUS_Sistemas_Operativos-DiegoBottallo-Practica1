#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

char * prog_name;

void mensaje(FILE * stream, int exit_code)
{
   fprintf( stream ,"Uso: %s <quien> <+|_> <modo> \n\n", prog_name );
   fprintf( stream ,
	   "PRIMER ARGUMENTO INDICA A QU�EN SE APLICA LOS PERMISOS: \n"
	   "PUEDE SER CUALQUIER COMBINACI�N SIN REPETICI�N DE:\n"
	   "	-u	O SU FORMATO LARGO	--USUARIO\n"
	   "	-g	O SU FORMATO LARGO 	--GRUPO\n"
	   "	-o	O SU FORMATO LARGO	--OTROS\n"
	   "	-a	O SU FORMATO LARGO	--TODOS\n"
	   "SEGUNDO ARGUMENTO INDICA COMO SE REALIZA LA APLICACI�N DE LOS PERMISOS ADMITIENDO: \n"
	   "	-+	O SU FORMATO LARGO	--MAS		OTORGAMIENTO DE PERMISOS\n"
	   "	-_	O SU FORMATO LARGO	--MENOS		DENEGAMIENTO DE PERMISOS\n"
	   "TERCER ARGUMENTO INDICA EL MODO DE LOS PERMISOS: \n"
	   "PUEDE SER CUALQUIER COMBINACI�N SIN REPETICI�N DE LAS LETRAS:\n"
	   "	-r	O SU FORMATO LARGO	--LECTURA\n"
	   "	-w	O SU FORMATO LARGO	--ESCRITURA\n"
	   "	-x	O SU FORMATO LARGO	--EJECUCI�N\n"
	   );
   exit(exit_code);
}

int main (int argc, char** argv) {
   int  next_opt;
   
   /*Opciones cortas*/
   char * opcionesCortas = "ugoa+_rwx";

   /*Opciones largas*/
   struct option opcionesLargas[] = {
      {"USUARIO", 0, NULL, 'u'},	// �ndice: 0
      {"GRUPO", 0, NULL, 'g'},		//    "  : 1
      {"OTROS", 0, NULL, 'o'},		//    "  : 2
      {"TODOS", 0, NULL, 'a'},		//    "  : 3
      {"MAS", 0, NULL, '+'},		//    "  : 4
      {"MENOS", 0, NULL, '_'},		//    "  : 5
      {"LECTURA", 0, NULL, 'r'},	//    "  : 6
      {"ESCRITURA", 0, NULL, 'w'},	//    "  : 7
      {"EJECUCI�N", 0, NULL, 'x'},	//    "  : 8
      {NULL, 0, NULL, 0}		//    "  : 9
   };
   prog_name = argv[0];

   if (argc < 4 || argc > 4)
      mensaje(stderr, 1);

   do {
      next_opt = getopt_long( argc , argv, opcionesCortas,
			     opcionesLargas , NULL );

      switch( next_opt ) {
         case 'u':
	    printf(" AL %s ", opcionesLargas[0].name );
	    break;
         case 'g':
	    printf("AL %s ", opcionesLargas[1].name );
	    break;
         case 'o':
	    printf("A LOS  %s ", opcionesLargas[2].name );
	    break;
         case 'a':
	    printf(" A %s ", opcionesLargas[3].name );
	    break;
	 case '+':
	    printf(" SE OTORGA PERMISO DE ");
	    break;
	 case '_':
	    printf(" SE REVOCA PERMISO DE ");
	    break;
	 case 'r':
	    printf(" %s ", opcionesLargas[6].name );
	    break;
	 case 'w':
	    printf(" %s ", opcionesLargas[7].name );
	    break;
	 case 'x':
	    printf(" %s ", opcionesLargas[8].name );
	    break;
	 case '?':
	    mensaje(stderr, 1);
	    break;
	 default:
	    abort(); /*Error inesperado*/
	    break;
      }
   } while(next_opt != -1);

   return 0;
}
