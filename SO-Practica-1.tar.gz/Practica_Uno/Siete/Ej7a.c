//Archivo: Ej7a.c
#include <stdio.h>
#include <stdarg.h>

/*** FUNCIONES ***/

/***
 * Funci�n:	void printf_light( char * , ... )
 *
 * Toma una lista de argumentos variable, cuyos tipo y
 * cantidad se desconocen de antemano.
 * Para ello utiliza los siguientes elementos definidos
 * en "stdarg.h":
 *    	un tipo "va_list"
 *    	tres macros :
 *    		"va_start"
 *    		"va_arg"
 *    		"va_end"
 *
 *    Los "3 puntos: ... " en el argumento de la funci�n
 *    indican que habr� argumentos variables en cantidad 
 *    y tipo de dato.
 ***/
void printf_light( char * formato , ... )
{
	va_list listaArgumentosVariables;

	int entero;	// usa cuando detecta un int
	double doble;	//  "    "  	 "     " double

	/* Con la macro "va_start" se indica que la 
	 * "listaArgumentosVariables" comienza a partir
	 * del �ltimo argumento de la funci�n del cu�l
	 * se conoce su tipo, es decir, "formato"
	 **/
	va_start( listaArgumentosVariables , formato );
	
	while( *formato ) //<==> while( *formato != '\0' )
	{
		switch( *formato )
		{
			case 'i' :	// detecta int
				/* Con la macro "va_arg" indica que va 
				 * sacar un argumento de la lista de
				 * argumentos variables cuyo tipo es el
				 * que se especifica.
				 * Se modifica internamente el "va_list"
				 * para que en una pr�xima llamada
				 * a "va_arg" devuelva el siguiente
				 * argumento correspondiente.
				 */
				entero = va_arg( listaArgumentosVariables , int );
				printf( "%d" , entero );
				break;

			case 'd':	// detecta double
				doble = va_arg( listaArgumentosVariables , double );
				printf( "%f" , doble );
				break;
		}
		formato++;
	}
	/* Con la macro "va_end" indica que la lista de argumentos
	 * variable ha finalizado y libera el espacio ocupado en memoria.
	 * Es obligatorio usarlo si se ha utilizado "va_start".
	 **/
	va_end( listaArgumentosVariables );
}

int main()
{
	int i = 1234;
	double d = 4312.3456;
	printf("\n");
	printf_light( "\tid\n" , i , d ); // solo imprime int's y double's
	printf("\n");
	return 0;	// Informa terminaci�n exitosa al entorno
}
// Fin del Archivo: Ej7a.c
