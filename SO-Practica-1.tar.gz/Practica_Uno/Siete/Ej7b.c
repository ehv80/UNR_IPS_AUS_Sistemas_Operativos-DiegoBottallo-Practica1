//Archivo: Ej7b.c
#include <stdio.h>

typedef struct vaList{
	void * parg;
} vaList;

static int entero;
static double doble;

// fmt es un "puntero a char"

// la barra '\' en el define se usa para
// seguir en otra l�nea el c�digo del define

#define vaStart(lista,fmt) vaList lista; \
	lista.parg = ( &fmt + sizeof(*fmt) );

/***
 * Se debe sumar a la direcci�n en memoria de fmt el
 * espacio que ocupa en memoria lo que contiene fmt, que a 
 * priori se desconoce.
 ***/
// lista es un "vaList"

#define vaArgI(lista,int) entero = (int)(*((int *)(lista.parg))); \
	lista.parg += sizeof(int);	
 
#define vaArgD(lista,double) doble = (double)(*((double *)(lista.parg))); \
 			lista.parg += sizeof(double);
				
#define vaEnd(lista) \
	lista.parg = NULL;

void printf_light( char * formato , ... )
{
	vaStart(lista,formato);
	
	while( *formato )
	{
		switch( *formato )
		{
			case 'i':	//detecta entero
				{
					vaArgI(lista,int);
					printf("\n%d\n" , entero );
					break;
				}
			case 'd':	//detecta double
				{
					vaArgD(lista,double);
					printf("\n%f\n" , doble );
					break;
				}
		}
		formato++;
	}
	vaEnd(lista);
}

int main()
{
	
	printf_light( "id" , 11 , 01.23 );

	printf_light( "ididid" , 1 , 01.01 , 2 , 02.02 , 3 , 03.03  );

	printf_light( "dididi" ,  04.04 , 4 , 05.05 , 5 , 06.06 , 6  );
	
	return 0;
}
//Fin del archivo: Ej7b.c
