// Archivo: prueba-uso-assert.c
#include <stdio.h>
#include <assert.h>

#undef NDEBUG

/* En el archivo assert.h hay definida una MACRO
 * (mediante #define) llamada "assert" cuya forma
 * de uso es:
 * 	
 * 	void assert (int expression)
 * 	
 * Si la macro NDEBUG NO EST� DEFINIDA =>
 * =>	Si la expresion que eval�a "assert" 
 * 	resulta VERDADERA (DISTINTA DE CERO) =>
 * 		=> NO OCURRE NADA
 * 	sino Si la expresion que eval�a "assert"
 * 	resulta FALSA (IGUAL A CERO) =>
 * 		=> imprime  un mensaje de error a 
 * 		   la salida est�ndar y termina el
 * 		   programa llamando a abort()
 * sino Si la macro NDEBUG EST� DEFINIDA =>
 * 	=> TODAS LAS APARICIONES DE LA MACRO 
 * 	   "assert" son IGNORADAS
 *
 * Nota: El comportamiento es indeterminado si la
 * 	expresi�n que eval�a "assert" posee efectos
 * 	colaterales (como por ejemplo ++ , -- )
 */	

int main()
{
	unsigned int nro;
	printf("INGRESE UN N�MERO POSITIVO: ");
	scanf("%u" , &nro ); //guarda como unsigned int
	
	assert( nro > 0 );	//FALLA SI INGRESA CERO
	/* Aqu� puede suceder:
	 * 
	 *  � se eval�a VERDADERA LA CONDICI�N y sigue
	 *  
	 *  � se eval�a FALSA LA CONDICI�N =>
	 *  	=> imprime mensaje en stderr 
	 *  	   (utilizando las MACROS PREDEFINIDAS
	 *  	   DEL PREPROCESADOR DE C, como __FILE__ ,
	 *  	   __LINE__ , etc) y llama a abort()
	 */

	printf("EL N�MERO QUE USTED INTRODUJO ES:\t %u \n" , nro );
	printf("EST� EN LA DIRECCI�N DE MEMORIA:\t %p \n" , &nro );
	printf("Y OCUPA:\t %d BYTES \t EN LA MEMORIA DEL SISTEMA.\n" , sizeof(nro) );
	
	return 0; // informa terminaci�n exitosa al entorno del S.O.
}
//Fin del archivo: prueba-uso-assert.c
