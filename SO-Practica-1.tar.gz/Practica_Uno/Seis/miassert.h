// Archivo: miassert.h
/* Trata de reemplazar a: /usr/include/assert.h
 * Toma dos argumentos:
 * 	
 * 	"condicion" es la expresi�n que se eval�a
 * 	
 * 	"cadena" es una cadena de caracteres que
 * 		contiene a la expresion representada
 * 		como cadena de caracteres, para poder
 * 		imprimir cu�l es la expresi�n que est�
 * 		siendo evaluada.
 */

#define miassert(condicion,cadena) \
	if( (condicion) != 0 ){/*NADA, POR SER VERDADERA*/} \
else if( (condicion) == 0 ){ \
 fprintf(stderr, "%s: %s:%d: %s: EXPRESI�N \`%s\' FALL�!\n", \
	 argv[0], __FILE__, __LINE__, __FUNCTION__, cadena ); \
	abort(); \
}
// Fin del archivo: miassert.h
