// Archivo: prueba-uso-miassert.c
#include <stdio.h>
#include "miassert.h"
#include <stdlib.h>

//Deja sin efecto la definici�n de NDEBUG
//#undef NDEBUG

/* En el archivo "miassert.h" se defini� una MACRO
 * que emula a "assert.h"
 */

int main( int argc , char ** argv)
{
	unsigned int nro;
	printf("INGRESE UN N�MERO POSITIVO: ");
	scanf("%u" , &nro );
	
	/* Una manera de poder imprimir cu�l es la
	 * expresi�n que se est� evaluando es pasarla
	 * como argumento a la macro "miassert" como 
	 * una cadena de caracteres: "expresion"
	 * En C, las cadenas de caracteres le indicamos
	 * su final mediante el CARACTER NULO: '\0'
	 */
	char * expresion = "nro > 0\0";
	miassert(nro>0,expresion);	//FALLA SI INGRESA CERO
	/* Aqu� puede suceder:
	 * 
	 *  � se eval�a VERDADERA LA CONDICI�N y sigue
	 *  
	 *  � se eval�a FALSA LA CONDICI�N =>
	 *  	=> imprime mensaje en stderr 
	 *  	   (utilizando las MACROS PREDEFINIDAS
	 *  	   DEL PREPROCESADOR DE C, como __FILE__ ,
	 *  	   __LINE__ , etc) y llama a abort()
	 */

	printf("EL N�MERO QUE USTED INTRODUJO ES:\t %u \n" , nro );
	printf("EST� EN LA DIRECCI�N DE MEMORIA:\t %p \n" , &nro );
	printf("Y OCUPA:\t %d BYTES \t EN LA MEMORIA DEL SISTEMA.\n" , sizeof(nro) );
	
	return 0; // informa terminaci�n exitosa al entorno del S.O.
}
//Fin del archivo: prueba-uso-miassert.c
