//Archivo: Ej8.c
#include <stdio.h>
#include <limits.h> //para ULONG_MAX

#define suma_segura(A,B)  \
	if( (B) <= ( ULONG_MAX - (A) ) ) \
	{ \
		printf("\n\tLA SUMA ES: %lu \n" , ((A)+(B)) ); \
	} \
	else \
	{ \
		printf("\n\tERROR POR EXCESO: OVERFLOW!\n"); \
	} 

int main()
{
	static unsigned long a , b ;	

	printf("INTRODUZCA UN VALOR ENTRE [ %lu , %lu ] PARA A: " , 0UL , ULONG_MAX );
	scanf( "%lu" , &a );
	
	printf("INTRODUZCA UN VALOR ENTRE [ %lu , %lu ] PARA B: " , 0UL , ULONG_MAX );
	scanf( "%lu" , &b );
	
	suma_segura( a , b );

	return 0;
}
//Fin del archivo: Ej8.c
