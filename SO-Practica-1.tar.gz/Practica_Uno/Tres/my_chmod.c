#include <stdio.h>
#include <string.h>

#define U 	printf("AL USUARIO ")
#define G 	printf("AL GRUPO ")
#define O 	printf("A LOS OTROS ")
#define A 	printf("A TODOS ")

#define R 	printf("PERMISO DE LECTURA ")
#define W 	printf("PERMISO DE ESCRITURA ")
#define X 	printf("PERMISO DE EJECUCI�N ")

#define MAS		printf("SE OTORG� ")
#define MENOS		printf("SE REVOC� ")
#define NUEVALINEA	printf("\n")


/**************************** PROTOTIPOS ***************************/
void mensaje(void);

/**************************** FUNCIONES ***************************/
void mensaje()
{
	printf("FORMA CORRECTA DE USAR EL PROGRAMA: \n" );
	printf("PRIMER ARGUMENTO PUEDE SER CUALQUIER COMBINACI�N SIN REPETICI�N DE LAS LETRAS \n");
	printf("	u	QUE SE REFIERE AL USUARIO\n");
	printf("	g	QUE SE REFIERE AL GRUPO\n");
	printf("	o	QUE SE REFIERE A LOS OTROS USUARIOS\n");
	printf("	a	QUE SE REFIERE A TODOS LOS USUARIOS\n");
	printf("SEGUNDO ARGUMENTO PUEDE SER UNA DE ENTRE LOS SIGUIENTES S�MBOLOS: \n");
	printf("	+	QUE SIGNIFICA OTORGAMIENTO DE PERMISOS \n");
	printf("	-	QUE SIGNIFICA DENEGACI�N DE PERMISOS\n");
	printf("TERCER ARGUMENTO PUEDE SER CUALQUIER COMBINACI�N SIN REPETICI�N DE LAS LETRAS: \n");
	printf("	r	QUE SE REFIERE AL PERMISO DE LECTURA\n");
	printf("	w	QUE SE REFIERE AL PERMISO DE ESCRITURA\n");
	printf("	x	QUE SE REFIERE AL PERMISO DE EJECUCI�N\n");
}

/******************* FUNCI�N PRINCIPAL MAIN ***********************/

/* contadorArgumentos: contiene la cantidad de argumentos que 
 * se observan en la l�nea de comandos cuando se est� invocando al 
 * programa (el nombre del programa tambi�n se cuenta como un
 * argumento)
 *
 * vectorArgumentos: es un puntero a un arreglo de
 * cadenas de caracteres que contiene los argumentos uno por 
 * cadena. 
 * Cada cadena termina con un caracter indicador de fin: "\0"
 * 	0 <= indice <= (contadorAgumentos - 1)
 * vectorArgumentos[contadorArgumentos] debe valer NULL.
 * (pag. 126 del Libro "El Lenguaje de Programaci�n C" de 
 * Brian W. Kernighan y Dennis M. Ritchie)
 */
int main( int contadorArgumentos , char ** vectorArgumentos )
{
	/* 1� PRUEBA: Considero que contadorArgumentos puede valer 
	 * a lo sumo 4
	 * 
	 * vectorArgumentos[0] siempre es el nombre del programa
	 * 
	 * vectorArgumentos[1] puede valer "u\0" o "g\0" o "o\0" o "a\0" o
	 * 			"ug\0" que es lo mismo que "gu\0" o
	 * 			"uo\0" que es lo mismo que "ou\0" o
	 * 			"go\0" que es lo mismo que "og\0" o
	 *			"ugo\0" que es lo mismo que "uog\0"
	 *  que es lo mismo que "guo\0" "   "  "   "    "   "gou\0"
	 *   "  "  "    "    "  "oug\0" "   "  "   "    "   "ogu\0"
	 * 
	 * vectorArgumentos[2] puede valer "+\0" o "-\0"
	 *
	 * vectorArgumentos[3] puede valer "r\0" o "w\0" o "x\0" o
	 * 	"rw\0" que es lo mismo que "wr\0" o
	 * 	"rx\0"  "  "   "  "     "  "xr\0" o
	 * 	"wx\0"  "  "   "  "     "  "xw\0" o
	 * 	"rwx\0" "  "   "  "     "  "rxw\0" que es lo mismo que
	 * 	"wrx\0" "  "   "  "     "  "wxr\0"  "  "   "   "    "
	 * 	"xrw\0" "  "   "  "     "  "xwr\0"
	 */

	switch( contadorArgumentos )
	{
		case 4:
			{
				int operador;
				char * quien  = vectorArgumentos[1] ,
				     * modo = vectorArgumentos[3] ;
				if( ( operador = strcmp( vectorArgumentos[2] , "+\0" ) ) == 0 )
				{
					MAS;
				}
				else if( ( operador = strcmp( vectorArgumentos[2] , "-\0" ) ) == 0 )
				{
					MENOS;
				}
				while( (*quien) != '\0' )
				{
					switch( *quien )
					{
						case 'u': U; break;
						case 'g': G; break;
						case 'o': O; break;
						case 'a': A; break;
						default: NUEVALINEA; break;
					}
					quien++;// apunta al siguiente caracter de la cadena
				}
				while( (*modo) != '\0' )
				{
					switch( *modo )
					{
						case 'r': R; break;
						case 'w': W; break;
						case 'x': X; break;
						default: NUEVALINEA; break;
					}
					modo++; //apunta al siguiente caracter de la cadena
				}
			}
		default: NUEVALINEA; break;
	}
	if( contadorArgumentos != 4 )
	{
		mensaje();
	}
	return 0; // Informa al entorno la finalizaci�n exitosa del programa
}
