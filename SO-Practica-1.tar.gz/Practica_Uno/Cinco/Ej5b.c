//Archivo: Ej5b.c
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>	// para INT_MIN e INT_MAX

/*** FUNCIONES ***/

/***	Funci�n: int pruebaSiEsPar( int nro )
 * 
 * Compara el "bit menos significativo de nro" 
 * (el bit de la posici�n CERO-�SIMA, el que est�
 * en el extremo derecho ) con 1, entonces
 * (bit menos significativo de nro) & 1 = 1, s� y
 * solo s�: (bit menos significativo de nro) = 1
 *  Por lo tanto nro n� es potencia de 2 (n� es par).
 *  En caso contrario el nro es potencia de 2.
 ***/
int pruebaSiEsPar( int nro )
{
	int tmp = (nro & 1);
	switch( tmp )
	{
	   // nro & 1 = 0 => bit menos significativo de nro = 0
		case 0:
			return 0; //=> nro es potencia de 2 (par)
			
	   // nro & 1 = 1 => bit menos significativo de nro = 1
		case 1:
			return 1; //=> nro N� ES POTENCIA DE 2
			
		default:
			printf("\tERROR en: int pruebaSiEsPar( int ) !\n");
			exit(-1);
	}
	exit(-1); //Si llega aqu� es porque algo raro ha sucedido
}

int main()
{
	int numero;
	printf("Introduzca un entero comprendido en el intervalo abierto ( %d , %d ): " 
			, INT_MIN , INT_MAX );
	scanf( "%d" , &numero );
	if( numero == 0 )
	{
		printf("Usted ingres� el CERO!\n");
		return 0;
	}
	else{
		if( pruebaSiEsPar( numero ) == 0 )
			printf("\tEste n�mero ES POTENCIA DE DOS\n");
		else if( pruebaSiEsPar( numero ) == 1 )
			printf("\tEste n�mero N� ES POTENCIA DE DOS!!!\n");
	}
	return 0;
}
//Fin del Archivo: Ej5b.c
