//Archivo: Ej5a.c
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


/*** FUNCIONES ***/
int absoluto( int nro )
{
	int tmp = nro;
	tmp = tmp >> 31; // desplazamiento de 31 bits hacia la derecha
	int res = ( tmp & 1);
	switch( res )
	{
		case 1:	// 1 & 1 = 1 => es negativo
			return ( nro * (-1) );
		case 0:	// 0 & 1 = 0 => es positivo
			return ( nro );
		default:
			printf("ALG�N ERROR HA OCURRIDO!!!\n");
			exit(-1);
	}
	exit(-1);
}

int main()
{
	int numero, tamanio = sizeof(int);
	printf( "Un entero ocupa en memoria: %d bytes = %d bits\n" , 
			tamanio , tamanio*8 );
	printf("Ingrese un entero, comprendido en el intervalo abierto ( %d , %d ) : ", 
			INT_MIN , INT_MAX);
	scanf( "%d" , &numero );
	int resultado = absoluto( numero );
	printf( "\tVALOR ABSOLUTO( %d ) = %d \n" , numero , resultado );
	
	return 0;
}
//Fin del archivo: Ej5a.c
