#include <stdio.h>

/*** DEFINICIONES DE PREPROCESADOR ***/

#define MAX 32000

/***
 * Supone que el RANGO de VALORES del CONJUNTO
 * m�s general o ESPACIOS DE CONJUNTOS es 
 * [0,MAX] (inclu�dos ambos extremos, intervalo cerrado)
 ***/

#define SET_A(i) (arrA[i/8] |= (1<<(i%8)))
#define CHECK_A(i) (arrA[i/8] & (1<<(i%8)))

#define SET_COMP_A(i) (arrcompA[i/8] |= (1<<(i%8)))
#define CHECK_COMP_A(i) (arrcompA[i/8] & (1<<(i%8)))

#define SET_B(i) (arrB[i/8] |= (1<<(i%8)))
#define CHECK_B(i) (arrB[i/8] & (1<<(i%8)))

#define SET_COMP_B(i) (arrcompB[i/8] |= (1<<(i%8)))
#define CHECK_COMP_B(i) (arrcompB[i/8] & (1<<(i%8)))

#define SET_RES(i) (arrResultado[i/8] |= (1<<(i%8)))
#define CHECK_RES(i) (arrResultado[i/8] & (1<<(i%8)))

#define TRUE 1
#define FALSE 0

/*** VARIABLES GLOBALES ***/

char arrA[MAX/8+1];	//MAPA DE BIT OPERANDO A
char arrcompA[MAX/8+1];	//MAPA DE BIT COMPLEMENTO DE A
char arrB[MAX/8+1];	//MAPA DE BIT OPERANDO B
char arrcompB[MAX/8+1];	//MAPA DE BIT COMPLEMENTO B
char arrResultado[MAX/8+1];	//MAPA DE BIT RESULTADO

/***
 * EL MAPA DE BITS: UN ARREGLO DE 4001 elementos
 * de tipo char.
 * Suponemos que usa un MAPA DE BITS �nico y distinto
 * para cada conjunto de valores que va ingresando el usuario
 * donde se va poniendo las marcas de cada elemento.
 * En el MAPA DE BITS "resultado" es donde se almacena el
 * MAPA DE BIT resultante de las operaciones:
 *  - UNION entre conjuntos
 *  - INTERSECCI�N entre conjuntos
 *  
 * CONJUNTO	MAPA DE BITS ASOCIADO AL CONJUNTO
 * --------	---------------------------------
 * 	A	char arrA[MAX/8+1]
 * 	B	char arrB[MAX/8+1]
 * resultado	char arrResultado[MAX/8+1]	
 *     ~A	char arrcompA[MAX/8+1]
 *     ~B	char arrcompB[MAX/8+1]
 *     
 * La operaci�n de igualdad recorre dos MAPAS DE BITS
 * distintos y si resultan iguales retorna TRUE, de otra
 * manera retorna FALSE.
 ***/

/*** FUNCIONES ***/
void complemento( int nro , char nombreConj )
{
	switch( nombreConj )
	{
		case 'A' :
			{
				printf("\nCOMPLEMENTO DEL CONJUNTO %c :\n" , nombreConj );
				for( nro=0 ; nro <= MAX ; nro++ )
				{
					if( CHECK_A( nro ) )
					{
						/* Si est� en el MAPA DE BITS asociado al
						 * CONJUNTO A NO LO IMPRIME
						 */
					}
					else if( (CHECK_A( nro )) == FALSE )
					{
						printf("\t%d\t" , nro );
						/* Imprime todos aquellos que
						 * est�n en el rango [0,MAX]
						 * excepto los que haya ingresado
						 * el usuario, es decir el
						 * COMPLEMENTO DEL CONJUNTO DE VALORES
						 * QUE INGRES� EL USUARIO.
						 */
						SET_COMP_A( nro );
						/* Va marcando cada elemento del conjunto
						 * Complemento de A mediante SET_COMP_A, por lo
						 * tanto sea A un conjunto, el complemento
						 * de A estar� en "arrcompA".
						 */
					}
				}
			}
			break;
		case 'B' :
			{
				printf("\nCOMPLEMENTO DEL CONJUNTO %c :\n" , nombreConj );
				for( nro=0 ; nro <= MAX ; nro++ )
				{
					if( CHECK_B( nro ) )
					{
						/* Si est� en el MAPA DE BITS asociado
						 * al CONJUNTO B NO LO IMPRIME
						 */
					}
					else if( (CHECK_B( nro )) == FALSE )
					{
						printf("\t%d\t" , nro );
						/* Imprime todos aquellos que
						 * est�n en el rango [0,MAX]
						 * excepto los que haya ingresado
						 * el usuario, es decir el
						 * COMPLEMENTO DEL CONJUNTO DE VALORES
						 * QUE INGRES� EL USUARIO.
						 */
						SET_COMP_B( nro );
						/* Va marcando cada elemento del conjunto
						 * Complemento de B mediante SET_COMP_B, por lo
						 * tanto sea B un conjunto, el complemento
						 * de B estar� en "arrcompB".
						 */
					}
				}
			}
			break;
		default:
			printf("ERROR INESPERADO HA OCURRIDO!!!\n");
			break;
	}
}

void interseccion( int nro , char nombreConj1 , char nombreConj2 )
{
	for( nro=0 ; nro <= MAX ; nro++ )
	{
		if( (CHECK_A(nro)) && (CHECK_B(nro)) )
		{
			SET_RES(nro);
		}
	}
	printf("\nEL CONJUNTO QUE RESULTA DE HACER:\n");
	printf("\t\"CONJUNTO %c\" INTERSECCI�N \"CONJUNTO %c\" es el siguiente:\n", 
			nombreConj1 , nombreConj2);
	for( nro=0 ; nro <= MAX ; nro++ )
	{
		if( CHECK_RES(nro) )
		{
			printf("\t%d\t",nro);
		}
	}
	printf("\n------------------------[NOTA]-----------------------------\n");
	printf("\n\nOBSERVE QUE DE NO IMPRIMIRSE NADA EN PANTALLA\n");
	printf("SIGNIFICA QUE EL CONJUNTO INTERSECCI�N ES EL\n");
	printf("\"CONJUNTO VAC�O\".\n");
	printf("\n----------------------[FIN NOTA]-----------------------------\n");
}

//Guarda: union es una palabra reservada en el Lenguaje C
void op_union( int nro , char nombreConj1 , char nombreConj2 )
{
	for( nro=0 ; nro <= MAX ; nro++ )
	{
		if( (CHECK_A(nro)) || (CHECK_B(nro)) )
		{
			SET_RES(nro);
		}
	}
	printf("\nEL CONJUNTO QUE RESULTA DE HACER:\n");
	printf("\t\"CONJUNTO %c\" UNI�N \"CONJUNTO %c\" es el siguiente:\n",
	                        nombreConj1 , nombreConj2);
	for( nro=0 ; nro <= MAX ; nro++ )
	{
		if( CHECK_RES(nro) )
		{
			printf("\t%d\t" , nro);
		}
	}
	printf("\n------------------------[NOTA]-----------------------------\n");
	printf("\n\nNOTA: OBSERVE QUE DE NO IMPRIMIRSE NADA EN PANTALLA\n");
	printf("SIGNIFICA QUE EL CONJUNTO UNI�N ES EL\n");
	printf("\"CONJUNTO VAC�O\".\n");
	printf("\n----------------------[FIN NOTA]-----------------------------\n");
}

int igualdad( int nro )
{
	int resultado=TRUE;
	/* Recorre los MAPAS DE BITS operandos: "A" y "B" 
	 * verificando si ambos conjuntos contienen los mismos
	 * elementos.
	 * Si tienen los mismos elementos entonces retorna TRUE
	 * Si no tienen los mismos elementos entonces retorna FALSE
	 */
	for( nro=0 ; nro <= MAX ; nro++ )
	{
		if( (CHECK_A(nro)) && ( (CHECK_B(nro)) == FALSE ) )
		{
			resultado=FALSE;
			return resultado;
		}
		else if( ( (CHECK_A(nro)) == FALSE) && (CHECK_B(nro)) )
		{
			resultado=FALSE;
			return resultado;
		}
	} // Si recorre todo el for sin retornar entonces es porque son iguales
	return resultado;
}

void verificaIgualdad( int nro )
{
	if( igualdad(nro) == FALSE )
	{
		printf("\nEL \"CONJUNTO A\" NO ES IGUAL AL \"CONJUNTO B\".\n" );
	}
	else if( igualdad(nro) == TRUE )
	{
		printf("\nEL \"CONJUNTO A\" ES IGUAL AL \"CONJUNTO B\".\n" );
	}
}
/*** FUNCI�N PRINCIPAL MAIN ***/
int main () {
  int nro;
	    
  printf("\nINGRESE LOS ELEMENTOS DEL CONJUNTO A:\n");
  do {
    scanf("%d", &nro);
    SET_A(nro);
  } while (nro >= 0);	
  // TERMINA CUANDO USUARIO INGRESA N�MERO NEGATIVO

  printf("\nELEMENTOS DEL CONJUNTO A EN ORDEN ASCENDENTE:\n");
  for (nro=0; nro<=MAX; nro++)
    if (CHECK_A(nro)) // CHEQUEA SI ESE N�MERO EST� EN EL MAPA DE BITS
      printf("%d ", nro);

  complemento(nro , 'A' );

  printf("\nINGRESE LOS ELEMENTOS DEL CONJUNTO B:\n");
  do {
    scanf("%d", &nro);
    SET_B(nro);
  } while (nro >= 0);	
  // TERMINA CUANDO USUARIO INGRESA N�MERO NEGATIVO

  printf("\nELEMENTOS DEL CONJUNTO B EN ORDEN ASCENDENTE:\n");
  for (nro=0; nro<=MAX; nro++)
    if (CHECK_B(nro)) // CHEQUEA SI ESE N�MERO EST� EN EL MAPA DE BITS
      printf("%d ", nro);
  
  complemento( nro , 'B' );

  interseccion( nro , 'A' , 'B' );

  op_union( nro , 'A' , 'B' );

  verificaIgualdad( nro );
  
  return 0;
}
